/**
Arbitrary precision calculator interactive application.<p>
*/

package org.apfloat.calc;
